package com.ribomod.ribo.proxy;

/**
 * CommonProxy
 *
 * Implementacao padrao usada no lado do servidor (dedicated server), onde nao existe
 * renderizacao. O ClientProxy sobrescreve registerRenderers para registrar a skin
 * do Ribo apenas no cliente.
 */
public class CommonProxy
{
    public void registerRenderers()
    {
        // Vazio no servidor: nao ha nada para renderizar.
    }
}
