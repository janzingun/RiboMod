package com.ribomod.ribo.proxy;

import com.ribomod.ribo.client.render.RenderRibo;
import com.ribomod.ribo.entity.EntityRibo;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * ClientProxy
 *
 * No lado do cliente, registra o renderer customizado do Ribo, que usa a skin
 * classica do Steve (ver RenderRibo).
 */
public class ClientProxy extends CommonProxy
{
    @Override
    @SideOnly(Side.CLIENT)
    public void registerRenderers()
    {
        RenderingRegistry.registerEntityRenderingHandler(EntityRibo.class, new RenderRibo.Factory());
    }
}
