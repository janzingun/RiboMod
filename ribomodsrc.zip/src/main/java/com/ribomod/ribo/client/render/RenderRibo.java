package com.ribomod.ribo.client.render;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.IRenderFactory;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * RenderRibo
 *
 * Renderiza o Ribo usando o MODELO PADRAO DE JOGADOR (biped) com a TEXTURA CLASSICA
 * DO STEVE (skin padrao embutida no proprio jogo: "textures/entity/steve.png").
 *
 * Estendemos RenderBiped<EntityRibo> (mesma base usada para zumbis, esqueletos etc,
 * que tem formato humanoide) e simplesmente apontamos a textura para a skin do Steve,
 * em vez de criar um modelo customizado.
 */
@SideOnly(Side.CLIENT)
public class RenderRibo extends RenderBiped<EntityRibo>
{
    // Caminho vanilla da skin classica do Steve, embutida no minecraft.jar.
    private static final ResourceLocation STEVE_TEXTURE =
            new ResourceLocation("minecraft", "textures/entity/steve.png");

    public RenderRibo(RenderManager renderManager)
    {
        super(renderManager, new ModelBiped(), 0.5F);
    }

    // Assinatura herdada de Render<T>: protected abstract ResourceLocation getEntityTexture(T entity);
    // O parametro precisa ser exatamente do tipo generico T (EntityRibo) para o @Override ser valido.
    @Override
    protected ResourceLocation getEntityTexture(EntityRibo entity)
    {
        return STEVE_TEXTURE;
    }

    /**
     * Factory usada no registro do render (RenderingRegistry.registerEntityRenderingHandler).
     */
    @SideOnly(Side.CLIENT)
    public static class Factory implements IRenderFactory<EntityRibo>
    {
        @Override
        public Render<EntityRibo> createRenderFor(RenderManager manager)
        {
            return new RenderRibo(manager);
        }
    }
}
