package com.ribomod.ribo.init;

import com.ribomod.ribo.RiboMod;
import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

/**
 * Classe responsavel por registrar a entidade Ribo no jogo.
 * Em 1.12.2 o registro de entidades customizadas usa EntityRegistry.registerModEntity.
 */
public class ModEntities
{
    // ID interno do mod para a entidade (deve ser unico dentro do proprio mod).
    private static final int RIBO_ENTITY_ID = 1;

    public static void registerEntities()
    {
        EntityRegistry.registerModEntity(
                new ResourceLocation(RiboMod.MODID, "ribo"),
                EntityRibo.class,
                "ribo",
                RIBO_ENTITY_ID,
                RiboMod.instance,
                64,   // trackingRange: distancia em blocos para sincronizar com clientes
                1,    // updateFrequency: a cada quantos ticks atualiza
                true  // sendsVelocityUpdates: necessario para movimentacao fluida
        );
    }
}
