package com.ribomod.ribo.handler;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * RiboEventHandler
 *
 * Responsavel por:
 * 1. Spawnar o Ribo automaticamente ao lado do jogador na primeira vez que ele
 *    entra no mundo (login), usando uma flag salva no NBT do jogador para garantir
 *    que isso so aconteca uma unica vez por jogador.
 * 2. Interceptar mensagens de chat do jogador para dar comandos simples ao Ribo
 *    (ex: "ribo minerar", "ribo parar").
 * 3. Processar o clique direito do jogador no Ribo: saudacao, status e entrega
 *    automatica dos minerios coletados para o inventario do jogador.
 */
public class RiboEventHandler
{
    // Controle simples em memoria para nao tentar spawnar de novo no mesmo login.
    private final Set<UUID> alreadySpawnedThisSession = new HashSet<>();

    /**
     * Dispara quando o jogador entra no mundo (login ou respawn no overworld pela primeira vez).
     * Usamos uma tag persistente no NBT do jogador ("RiboHasSpawned") para garantir que o
     * Ribo apareca apenas UMA vez na vida daquele jogador, mesmo que ele relogue depois.
     */
    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event)
    {
        EntityPlayer player = event.player;
        if (!(player instanceof EntityPlayerMP))
        {
            return;
        }

        if (this.alreadySpawnedThisSession.contains(player.getUniqueID()))
        {
            return;
        }

        boolean hasSpawnedBefore = player.getEntityData().getBoolean("RiboHasSpawned");
        if (hasSpawnedBefore)
        {
            return;
        }

        spawnRiboNextToPlayer(player);
        player.getEntityData().setBoolean("RiboHasSpawned", true);
        this.alreadySpawnedThisSession.add(player.getUniqueID());
    }

    private void spawnRiboNextToPlayer(EntityPlayer player)
    {
        World world = player.world;
        EntityRibo ribo = new EntityRibo(world);

        // Posiciona o Ribo a 2 blocos de distancia do jogador, na mesma altura.
        double spawnX = player.posX + 2.0;
        double spawnY = player.posY;
        double spawnZ = player.posZ;

        ribo.setLocationAndAngles(spawnX, spawnY, spawnZ, player.rotationYaw, 0.0F);
        ribo.setOwnerUUID(player.getUniqueID());
        ribo.setHomeAnchor(ribo.getPosition());
        ribo.enablePersistence(); // garante que o Ribo nao seja removido por despawn natural

        world.spawnEntity(ribo);

        player.sendMessage(new TextComponentString(
                TextFormatting.GREEN + "Ribo" + TextFormatting.WHITE + " apareceu para te acompanhar na sua jornada!"
        ));
    }

    /**
     * Intercepta o chat do jogador para comandos simples direcionados ao Ribo.
     * Comandos suportados:
     *   "ribo minerar"  -> ativa a ordem de mineracao
     *   "ribo parar"    -> cancela a ordem de mineracao em andamento
     */
    @SubscribeEvent
    public void onPlayerChat(ServerChatEvent event)
    {
        String msg = event.getMessage().trim().toLowerCase();
        EntityPlayer player = event.getPlayer();

        EntityRibo ribo = findRiboOwnedBy(player);
        if (ribo == null)
        {
            return; // jogador nao possui um Ribo proximo, ignora o comando
        }

        if (msg.equals("ribo minerar") || msg.equals("ribo, minerar"))
        {
            event.setCanceled(true); // nao mostra esse comando como mensagem normal de chat
            if (ribo.isResting())
            {
                player.sendMessage(new TextComponentString(
                        TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                                "Estou descansando, preciso recuperar energia antes de continuar..."
                ));
            }
            else
            {
                ribo.setMiningOrderActive(true);
                player.sendMessage(new TextComponentString(
                        TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                                "Entendido! Vou procurar minerios por perto."
                ));
            }
        }
        else if (msg.equals("ribo parar"))
        {
            event.setCanceled(true);
            ribo.setMiningOrderActive(false);
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE + "Ok, parei o que estava fazendo."
            ));
        }
    }

    /**
     * Clique direito no Ribo: saudacao + informe de status + entrega automatica
     * dos minerios coletados para o inventario do jogador.
     */
    @SubscribeEvent
    public void onPlayerInteractWithRibo(PlayerInteractEvent.EntityInteract event)
    {
        if (!(event.getTarget() instanceof EntityRibo))
        {
            return;
        }

        EntityRibo ribo = (EntityRibo) event.getTarget();
        EntityPlayer player = event.getEntityPlayer();

        // So responde/entrega itens para o proprio dono.
        if (ribo.getOwnerUUID() == null || !ribo.getOwnerUUID().equals(player.getUniqueID()))
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GRAY + "Ribo olha para voce, mas parece nao te reconhecer."
            ));
            return;
        }

        // ===================== DIALOGO DE STATUS =====================
        if (ribo.isResting())
        {
            int secondsLeft = ribo.getRestTicksRemaining() / 20;
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Estou cansado e preciso descansar. Faltam aproximadamente " + secondsLeft + "s."
            ));
        }
        else if (ribo.isMiningOrderActive())
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Estou minerando por aqui! Energia atual: " + ribo.getEnergy() + "/" + EntityRibo.MAX_ENERGY + "."
            ));
        }
        else
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Ola! Estou pronto para te ajudar. Diga 'ribo minerar' para eu procurar minerios."
            ));
        }

        // ===================== ENTREGA DOS MINERIOS COLETADOS =====================
        if (ribo.hasOresToDeliver())
        {
            int itemsDelivered = deliverOresToPlayer(ribo, player);
            if (itemsDelivered > 0)
            {
                player.sendMessage(new TextComponentString(
                        TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                                "Aqui estao os minerios que coletei para voce!"
                ));
            }
        }

        event.setCanceled(true); // evita qualquer outra interacao padrao (ex: GUI de aldeao)
    }

    /**
     * Transfere todo o conteudo do inventario interno do Ribo para o inventario do jogador.
     * Caso o inventario do jogador esteja cheio, o item que nao couber e dropado no chao
     * proximo ao jogador (nunca e perdido).
     */
    private int deliverOresToPlayer(EntityRibo ribo, EntityPlayer player)
    {
        int count = 0;
        for (int i = 0; i < ribo.getOreInventory().size(); i++)
        {
            ItemStack stack = ribo.getOreInventory().get(i);
            if (!stack.isEmpty())
            {
                boolean added = player.inventory.addItemStackToInventory(stack);
                if (!added || !stack.isEmpty())
                {
                    // Inventario do jogador cheio: dropa o restante no chao ao lado dele.
                    player.dropItem(stack, false);
                }
                count++;
            }
        }
        ribo.clearOreInventory();
        return count;
    }

    /** Procura, entre as entidades carregadas no mundo do jogador, o Ribo cujo dono e este jogador. */
    private EntityRibo findRiboOwnedBy(EntityPlayer player)
    {
        for (Entity entity : player.world.loadedEntityList)
        {
            if (entity instanceof EntityRibo)
            {
                EntityRibo ribo = (EntityRibo) entity;
                if (player.getUniqueID().equals(ribo.getOwnerUUID()))
                {
                    return ribo;
                }
            }
        }
        return null;
    }
}
