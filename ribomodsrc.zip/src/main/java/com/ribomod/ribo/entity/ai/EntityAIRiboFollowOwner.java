package com.ribomod.ribo.entity.ai;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

/**
 * EntityAIRiboFollowOwner
 *
 * Faz o Ribo seguir o jogador "dono" de perto, igual a um lobo/cachorro domesticado:
 * - Se a distancia for pequena, apenas caminha em direcao ao jogador (pathfinding normal).
 * - Se a distancia ficar grande demais (jogador correu, atravessou portal, etc.),
 *   o Ribo se teleporta para perto do jogador em vez de ficar perdido tentando andar.
 *
 * Esta tarefa fica "inativa" (nao faz nada) enquanto o Ribo esta executando uma ordem
 * de mineracao (miningOrderActive) ou descansando parado em um ponto fixo - nesse caso
 * a tarefa de mineracao tem prioridade mais alta na lista de tasks.
 */
public class EntityAIRiboFollowOwner extends EntityAIBase
{
    private final EntityRibo ribo;
    private EntityPlayer owner;
    private final double moveSpeed;
    private final float minDistance;   // distancia minima para comecar a se mover
    private int updateCounter;

    private static final float TELEPORT_DISTANCE = 16.0F; // estilo lobo: teleporta se ficar muito longe

    public EntityAIRiboFollowOwner(EntityRibo ribo, double moveSpeed, float minDistance, float maxDistanceForWalk)
    {
        this.ribo = ribo;
        this.moveSpeed = moveSpeed;
        this.minDistance = minDistance;
        // maxDistanceForWalk reservado para ajuste fino futuro (atualmente o limiar de
        // teleporte e controlado pela constante TELEPORT_DISTANCE).
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute()
    {
        // Nao segue enquanto estiver minerando ou descansando (essas tasks tomam prioridade).
        if (this.ribo.isMiningOrderActive() || this.ribo.isResting())
        {
            return false;
        }

        EntityPlayer player = this.ribo.getOwner();
        if (player == null || player.isDead)
        {
            return false;
        }

        double distSq = this.ribo.getDistanceSq(player);
        this.owner = player;
        return distSq > this.minDistance * this.minDistance;
    }

    @Override
    public boolean shouldContinueExecuting()
    {
        if (this.ribo.isMiningOrderActive() || this.ribo.isResting())
        {
            return false;
        }
        if (this.owner == null || this.owner.isDead)
        {
            return false;
        }
        return !this.ribo.getNavigator().noPath() || this.ribo.getDistanceSq(this.owner) > this.minDistance * this.minDistance;
    }

    @Override
    public void startExecuting()
    {
        this.updateCounter = 0;
    }

    @Override
    public void resetTask()
    {
        this.owner = null;
        this.ribo.getNavigator().clearPath();
    }

    @Override
    public void updateTask()
    {
        // Sempre olha para o dono.
        this.ribo.getLookHelper().setLookPositionWithEntity(this.owner, 10.0F, this.ribo.getVerticalFaceSpeed());

        if (--this.updateCounter > 0)
        {
            return;
        }
        this.updateCounter = 10; // recalcula a cada 10 ticks (meio segundo) para nao sobrecarregar pathfinding

        float distance = this.ribo.getDistanceToEntity(this.owner);

        // Estilo lobo domesticado: se ficou muito longe, teleporta para perto em vez de tentar andar a pe.
        if (distance > TELEPORT_DISTANCE)
        {
            this.tryTeleportToOwner();
            return;
        }

        // Caso contrario, apenas anda em direcao ao dono normalmente.
        if (distance > this.minDistance)
        {
            this.ribo.getNavigator().tryMoveToEntityLiving(this.owner, this.moveSpeed);
        }
        else
        {
            this.ribo.getNavigator().clearPath();
        }
    }

    /**
     * Tenta encontrar uma posicao segura proxima ao jogador e teleporta o Ribo para la.
     * Mesma logica usada pelo EntityWolf vanilla: tenta varios pontos em volta do dono.
     */
    private void tryTeleportToOwner()
    {
        BlockPos ownerPos = this.owner.getPosition();

        for (int i = 0; i < 10; i++)
        {
            // Gera deslocamentos entre -5 e +5 em X/Z e -2 a +2 em Y, similar ao EntityWolf vanilla,
            // garantindo que o ponto sorteado fique perto do dono mas nao exatamente em cima dele.
            int dx = this.ribo.getRNG().nextInt(11) - 5;
            int dy = this.ribo.getRNG().nextInt(5) - 2;
            int dz = this.ribo.getRNG().nextInt(11) - 5;
            boolean teleported = this.tryTeleportTo(ownerPos.getX() + dx, ownerPos.getY() + dy, ownerPos.getZ() + dz);
            if (teleported)
            {
                return;
            }
        }
    }

    private boolean tryTeleportTo(int x, int y, int z)
    {
        if (Math.abs((double) x - this.owner.posX) < 2.0D && Math.abs((double) z - this.owner.posZ) < 2.0D)
        {
            return false; // muito perto, nao precisa
        }

        if (!isPositionSafeForRibo(x, y, z))
        {
            return false;
        }

        this.ribo.setLocationAndAngles((double) x + 0.5D, y, (double) z + 0.5D, this.ribo.rotationYaw, this.ribo.rotationPitch);
        this.ribo.getNavigator().clearPath();
        return true;
    }

    private boolean isPositionSafeForRibo(int x, int y, int z)
    {
        BlockPos pos = new BlockPos(x, y, z);

        // Verifica se a posicao e o espaco acima estao livres (sem colisao) para o Ribo caber,
        // e se ha um bloco solido embaixo para ele nao cair no vazio.
        boolean spaceClear = isPassable(pos) && isPassable(pos.up());
        boolean groundSolid = this.ribo.world.getBlockState(pos.down()).isOpaqueCube();

        return spaceClear && groundSolid;
    }

    /** Considera "passavel" um bloco que nao bloqueia movimento (ar, grama baixa, etc.). */
    private boolean isPassable(BlockPos pos)
    {
        IBlockState state = this.ribo.world.getBlockState(pos);
        return !state.getMaterial().blocksMovement() && !state.getMaterial().isLiquid();
    }
}
