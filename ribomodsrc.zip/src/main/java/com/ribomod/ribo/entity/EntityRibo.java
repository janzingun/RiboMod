package com.ribomod.ribo.entity;

import com.ribomod.ribo.entity.ai.EntityAIRiboFleeFromDanger;
import com.ribomod.ribo.entity.ai.EntityAIRiboFollowOwner;
import com.ribomod.ribo.entity.ai.EntityAIRiboMineOres;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.EntityAgeable;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * EntityRibo
 *
 * Representa o companheiro "Ribo". Estende EntityVillager apenas para reaproveitar
 * a renderizacao humanoide padrao (modelo biped) e o ciclo de vida de "NPC amigavel"
 * do jogo, mas toda a IA de combate/comercio padrao do aldeao e removida e substituida
 * pela IA customizada do Ribo (seguir, minerar, fugir).
 *
 * O Ribo guarda seu proprio estado (energia, se esta minerando, dono, inventario
 * interno de minerios) dentro do NBT da entidade, entao tudo isso persiste
 * quando o mundo e salvo/recarregado.
 */
public class EntityRibo extends EntityVillager
{
    // ===================== CONSTANTES DE ENERGIA / FADIGA =====================
    /** Energia maxima do Ribo. Cada bloco minerado custa 1 ponto de energia. */
    public static final int MAX_ENERGY = 40;
    /** Quando a energia chega a 0, o Ribo precisa descansar por este numero de ticks (3 minutos = 3600 ticks). */
    public static final int REST_DURATION_TICKS = 20 * 60 * 3;

    // ===================== INVENTARIO INTERNO =====================
    /** Inventario interno onde ficam apenas os minerios validos coletados (capacidade 27 slots, como uma dispensa). */
    private final NonNullList<ItemStack> oreInventory = NonNullList.withSize(27, ItemStack.EMPTY);

    // ===================== ESTADO =====================
    private UUID ownerUUID;
    private int energy = MAX_ENERGY;
    private int restTicksRemaining = 0;
    private boolean miningOrderActive = false;
    /** Posicao de origem usada para o Ribo nao se afastar demais ao procurar minerio. */
    private BlockPos homeAnchor;

    public EntityRibo(World worldIn)
    {
        super(worldIn);
        this.setSize(0.6F, 1.95F); // mesmo tamanho de um jogador/Steve
        this.setCanPickUpLoot(false); // ele NAO pega itens soltos automaticamente, so via mineracao controlada
        // Remove a profissao de aldeao para evitar GUI de comercio/trade ao clicar.
        this.setProfession(0);
    }

    @Override
    protected void initEntityAI()
    {
        // Sobrescreve a IA padrao do EntityVillager (comercio, fuga de zombie, etc.)
        // com a IA customizada do Ribo.
        this.tasks.addTask(0, new EntityAIRiboFleeFromDanger(this)); // prioridade maxima: fugir se a vida estiver baixa
        this.tasks.addTask(1, new EntityAIRiboMineOres(this));        // minerar quando ordenado
        this.tasks.addTask(2, new EntityAIRiboFollowOwner(this, 1.0D, 10.0F, 2.0F)); // seguir o dono
    }

    @Override
    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.35D);
    }

    // ===================== LOOP PRINCIPAL =====================
    @Override
    public void onLivingUpdate()
    {
        super.onLivingUpdate();

        // Regenera energia lentamente enquanto descansa (cooldown de fadiga).
        if (this.restTicksRemaining > 0)
        {
            this.restTicksRemaining--;
            if (this.restTicksRemaining == 0)
            {
                this.energy = MAX_ENERGY; // descanso completo: energia restaurada
            }
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        // O Ribo nunca ataca monstros de volta (sem IA de combate), apenas registra o dano recebido.
        return super.attackEntityFrom(source, amount);
    }

    // Impede que o Ribo se reproduza/processe logica de aldeao (cura por porta, etc.)
    @Nullable
    @Override
    public EntityAgeable createChild(EntityAgeable ageable)
    {
        return null;
    }

    // ===================== GETTERS / SETTERS DE ESTADO =====================

    public NonNullList<ItemStack> getOreInventory()
    {
        return this.oreInventory;
    }

    /** Tenta adicionar um minerio ao inventario interno. Retorna false se estiver cheio (sobra dropa no chao). */
    public boolean addOreToInventory(ItemStack stack)
    {
        for (int i = 0; i < this.oreInventory.size(); i++)
        {
            ItemStack slot = this.oreInventory.get(i);
            if (slot.isEmpty())
            {
                this.oreInventory.set(i, stack);
                return true;
            }
            if (ItemStack.areItemsEqual(slot, stack) && slot.getCount() + stack.getCount() <= slot.getMaxStackSize())
            {
                slot.grow(stack.getCount());
                return true;
            }
        }
        return false; // inventario interno cheio
    }

    public void clearOreInventory()
    {
        for (int i = 0; i < this.oreInventory.size(); i++)
        {
            this.oreInventory.set(i, ItemStack.EMPTY);
        }
    }

    public boolean hasOresToDeliver()
    {
        for (ItemStack stack : this.oreInventory)
        {
            if (!stack.isEmpty())
            {
                return true;
            }
        }
        return false;
    }

    public int getEnergy()
    {
        return this.energy;
    }

    /** Consome 1 ponto de energia por bloco minerado. Se zerar, entra em estado de descanso obrigatorio. */
    public void consumeEnergy(int amount)
    {
        this.energy = Math.max(0, this.energy - amount);
        if (this.energy == 0)
        {
            this.startResting();
        }
    }

    public boolean isResting()
    {
        return this.restTicksRemaining > 0;
    }

    public void startResting()
    {
        this.restTicksRemaining = REST_DURATION_TICKS;
        this.miningOrderActive = false; // cancela qualquer ordem de mineracao em andamento
    }

    public int getRestTicksRemaining()
    {
        return this.restTicksRemaining;
    }

    public boolean isMiningOrderActive()
    {
        return this.miningOrderActive;
    }

    public void setMiningOrderActive(boolean active)
    {
        // Nao aceita novo comando de mineracao se estiver descansando.
        this.miningOrderActive = active && !this.isResting();
    }

    @Nullable
    public UUID getOwnerUUID()
    {
        return this.ownerUUID;
    }

    public void setOwnerUUID(UUID uuid)
    {
        this.ownerUUID = uuid;
    }

    @Nullable
    public EntityPlayer getOwner()
    {
        if (this.ownerUUID == null || this.world == null)
        {
            return null;
        }
        return this.world.getPlayerEntityByUUID(this.ownerUUID);
    }

    public void setHomeAnchor(BlockPos pos)
    {
        this.homeAnchor = pos;
    }

    public BlockPos getHomeAnchor()
    {
        return this.homeAnchor != null ? this.homeAnchor : this.getPosition();
    }

    // ===================== PERSISTENCIA (NBT) =====================
    @Override
    public void writeEntityToNBT(NBTTagCompound compound)
    {
        super.writeEntityToNBT(compound);
        if (this.ownerUUID != null)
        {
            compound.setString("RiboOwner", this.ownerUUID.toString());
        }
        compound.setInteger("RiboEnergy", this.energy);
        compound.setInteger("RiboRestTicks", this.restTicksRemaining);
        compound.setBoolean("RiboMiningActive", this.miningOrderActive);

        // Salva o inventario interno de minerios.
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < this.oreInventory.size(); i++)
        {
            ItemStack stack = this.oreInventory.get(i);
            if (!stack.isEmpty())
            {
                NBTTagCompound itemTag = new NBTTagCompound();
                itemTag.setInteger("Slot", i);
                stack.writeToNBT(itemTag);
                list.appendTag(itemTag);
            }
        }
        compound.setTag("RiboOreInventory", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound compound)
    {
        super.readEntityFromNBT(compound);
        if (compound.hasKey("RiboOwner"))
        {
            this.ownerUUID = UUID.fromString(compound.getString("RiboOwner"));
        }
        this.energy = compound.getInteger("RiboEnergy");
        this.restTicksRemaining = compound.getInteger("RiboRestTicks");
        this.miningOrderActive = compound.getBoolean("RiboMiningActive");

        NBTTagList list = compound.getTagList("RiboOreInventory", 10); // 10 = tipo NBTTagCompound
        for (int i = 0; i < list.tagCount(); i++)
        {
            NBTTagCompound itemTag = list.getCompoundTagAt(i);
            int slot = itemTag.getInteger("Slot");
            if (slot >= 0 && slot < this.oreInventory.size())
            {
                this.oreInventory.set(slot, new ItemStack(itemTag));
            }
        }
    }
}
