package com.ribomod.ribo.entity.ai;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * EntityAIRiboMineOres
 *
 * Logica principal de mineracao do Ribo. So executa quando "miningOrderActive" esta
 * true (ordem dada via chat ou GUI) e o Ribo nao esta descansando.
 *
 * FUNCIONAMENTO:
 * 1. Procura, num raio fixo em torno da posicao "home" do Ribo, o minerio valido mais
 *    proximo (ferro, ouro, diamante, carvao - incluindo variantes do Forge/outros mods
 *    marcadas com a ore dictionary, alem dos minerios vanilla).
 * 2. Caminha até o bloco encontrado.
 * 3. "Minera" o bloco: remove o bloco do mundo e decide o destino do item resultante:
 *      - Se for um minerio da lista de permitidos -> guarda no inventario interno do Ribo.
 *      - Se for "resto" (pedra, terra, cascalho, etc.) -> e descartado (dropado no chao
 *        imediatamente como EntityItem, sem ir para o inventario do Ribo). Isso evita que
 *        o Ribo acumule lixo enquanto cava o caminho até o minerio.
 * 4. Cada bloco minerado custa energia. Quando a energia chega a zero, a tarefa e
 *    interrompida e o Ribo entra em descanso obrigatorio (gerenciado pela EntityRibo).
 */
public class EntityAIRiboMineOres extends EntityAIBase
{
    private final EntityRibo ribo;
    private BlockPos targetOre;
    private int digTicks;
    private int searchCooldown; // evita repetir a busca pesada (varre um cubo grande) todo tick
    private static final int SEARCH_RADIUS = 16;          // raio de busca de minerio em blocos
    private static final int DIG_TIME_TICKS = 30;          // tempo para "minerar" cada bloco (1.5s)
    private static final int ENERGY_COST_PER_BLOCK = 1;    // custo de energia por bloco minerado
    private static final int SEARCH_COOLDOWN_TICKS = 20;   // so permite nova busca a cada 1 segundo

    public EntityAIRiboMineOres(EntityRibo ribo)
    {
        this.ribo = ribo;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute()
    {
        if (!this.ribo.isMiningOrderActive() || this.ribo.isResting() || this.ribo.getEnergy() <= 0)
        {
            return false;
        }

        // Throttle: a busca varre um cubo grande de blocos, entao so repete a cada SEARCH_COOLDOWN_TICKS.
        if (this.searchCooldown > 0)
        {
            this.searchCooldown--;
            return this.targetOre != null && isStillValidOre(this.targetOre);
        }
        this.searchCooldown = SEARCH_COOLDOWN_TICKS;

        // Procura um minerio valido proximo; se nao encontrar nenhum, nao ha o que fazer.
        this.targetOre = findNearestOre();
        return this.targetOre != null;
    }

    @Override
    public boolean shouldContinueExecuting()
    {
        return this.ribo.isMiningOrderActive()
                && !this.ribo.isResting()
                && this.ribo.getEnergy() > 0
                && this.targetOre != null
                && isStillValidOre(this.targetOre);
    }

    @Override
    public void startExecuting()
    {
        this.digTicks = 0;
        this.moveTowardsTarget();
    }

    @Override
    public void resetTask()
    {
        this.targetOre = null;
        this.digTicks = 0;
        this.ribo.getNavigator().clearPath();
    }

    @Override
    public void updateTask()
    {
        if (this.targetOre == null)
        {
            return;
        }

        double distSq = this.ribo.getDistanceSq(
                this.targetOre.getX() + 0.5,
                this.targetOre.getY() + 0.5,
                this.targetOre.getZ() + 0.5
        );

        // Ainda esta caminhando para o bloco-alvo.
        if (distSq > 3.0D)
        {
            if (this.ribo.getNavigator().noPath())
            {
                this.moveTowardsTarget();
            }
            return;
        }

        // Perto o suficiente: comeca/continua a "escavar" o bloco.
        this.ribo.getNavigator().clearPath();
        this.ribo.getLookHelper().setLookPosition(
                this.targetOre.getX() + 0.5, this.targetOre.getY() + 0.5, this.targetOre.getZ() + 0.5,
                10.0F, this.ribo.getVerticalFaceSpeed()
        );

        this.digTicks++;
        if (this.digTicks >= DIG_TIME_TICKS)
        {
            this.mineBlock(this.targetOre);
            this.digTicks = 0;
            this.targetOre = null; // vai procurar o proximo minerio no proximo updateTask via shouldContinueExecuting->shouldExecute
        }
    }

    private void moveTowardsTarget()
    {
        if (this.targetOre != null)
        {
            this.ribo.getNavigator().tryMoveToXYZ(
                    this.targetOre.getX() + 0.5,
                    this.targetOre.getY(),
                    this.targetOre.getZ() + 0.5,
                    1.0D
            );
        }
    }

    /**
     * Executa a mineracao real do bloco: remove do mundo, aplica o FILTRO DE ITENS
     * e consome energia do Ribo.
     */
    private void mineBlock(BlockPos pos)
    {
        IBlockState state = this.ribo.world.getBlockState(pos);
        Block block = state.getBlock();

        // Quebra o bloco no mundo (sem efeito de particulas customizado, usa o padrao do bloco).
        this.ribo.world.destroyBlock(pos, false);

        // ===================== FILTRO DE ITENS =====================
        // Regra de negocio principal: o Ribo so guarda minerios validos. Tudo o mais
        // (pedra, cobblestone, terra, cascalho, etc.) e considerado "resto" e e
        // dropado no chao na hora, nunca entra no inventario interno do Ribo.
        if (isValidOreBlock(block))
        {
            ItemStack oreDrop = new ItemStack(block, 1, block.damageDropped(state));
            boolean stored = this.ribo.addOreToInventory(oreDrop);
            if (!stored)
            {
                // Inventario interno cheio: dropa no chao em vez de perder o item.
                dropItemAt(pos, oreDrop);
            }
        }
        else
        {
            // Bloco de "resto": NUNCA vai para o inventario do Ribo, e descartado
            // imediatamente dropando no chao (comportamento identico a nao guardar nada).
            ItemStack wasteDrop = new ItemStack(block, 1, block.damageDropped(state));
            dropItemAt(pos, wasteDrop);
        }

        // Consome energia e verifica se entra em descanso (logica centralizada na EntityRibo).
        this.ribo.consumeEnergy(ENERGY_COST_PER_BLOCK);
    }

    private void dropItemAt(BlockPos pos, ItemStack stack)
    {
        if (stack.isEmpty())
        {
            return;
        }
        EntityItem entityItem = new EntityItem(
                this.ribo.world,
                pos.getX() + 0.5, pos.getY() + 0.2, pos.getZ() + 0.5,
                stack
        );
        this.ribo.world.spawnEntity(entityItem);
    }

    /**
     * Lista de minerios validos que o Ribo deve coletar: ferro, ouro, diamante e carvao
     * (vanilla). Blocos como pedra/cobblestone, terra e cascalho ficam de fora de proposito,
     * caindo no ramo de "resto" do filtro acima.
     */
    private boolean isValidOreBlock(Block block)
    {
        return block == Blocks.IRON_ORE
                || block == Blocks.GOLD_ORE
                || block == Blocks.DIAMOND_ORE
                || block == Blocks.COAL_ORE;
    }

    /** Confirma se o bloco-alvo ainda e um minerio valido (pode ter sido minerado por outra fonte nesse meio tempo). */
    private boolean isStillValidOre(BlockPos pos)
    {
        Block block = this.ribo.world.getBlockState(pos).getBlock();
        return isValidOreBlock(block);
    }

    /**
     * Busca, dentro de um cubo de raio SEARCH_RADIUS centrado na posicao "home" do Ribo,
     * o bloco de minerio valido mais proximo do Ribo.
     */
    private BlockPos findNearestOre()
    {
        BlockPos center = this.ribo.getPosition();
        List<BlockPos> candidates = new ArrayList<>();

        for (int dx = -SEARCH_RADIUS; dx <= SEARCH_RADIUS; dx++)
        {
            for (int dy = -SEARCH_RADIUS / 2; dy <= SEARCH_RADIUS / 2; dy++)
            {
                for (int dz = -SEARCH_RADIUS; dz <= SEARCH_RADIUS; dz++)
                {
                    BlockPos pos = center.add(dx, dy, dz);
                    if (isValidOreBlock(this.ribo.world.getBlockState(pos).getBlock()))
                    {
                        candidates.add(pos);
                    }
                }
            }
        }

        if (candidates.isEmpty())
        {
            return null;
        }

        // Ordena por distancia e retorna o mais proximo.
        candidates.sort(Comparator.comparingDouble(p -> p.distanceSq(center)));
        return candidates.get(0);
    }
}
