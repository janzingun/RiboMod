package com.ribomod.ribo.entity.ai;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * EntityAIRiboFleeFromDanger
 *
 * O Ribo NUNCA ataca monstros (nao possui nenhuma IA de combate registrada).
 * Esta tarefa cuida apenas da fuga: quando a vida do Ribo cai abaixo de um limiar
 * (30% da vida maxima), ele entra em "modo panico" e corre para longe do monstro
 * hostil mais proximo, com prioridade maxima sobre qualquer outra acao (inclusive
 * mineracao em andamento, que e pausada).
 */
public class EntityAIRiboFleeFromDanger extends EntityAIBase
{
    private final EntityRibo ribo;
    private EntityMob threat;
    private double fleeX, fleeY, fleeZ;
    private static final double LOW_HEALTH_RATIO = 0.30D; // foge com 30% de vida ou menos
    private static final double FLEE_SEARCH_RADIUS = 10.0D;
    private static final double FLEE_SPEED = 1.3D;

    public EntityAIRiboFleeFromDanger(EntityRibo ribo)
    {
        this.ribo = ribo;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute()
    {
        // So entra em modo fuga se a vida estiver baixa.
        if (this.ribo.getHealth() > this.ribo.getMaxHealth() * LOW_HEALTH_RATIO)
        {
            return false;
        }

        // Procura o monstro hostil mais proximo dentro do raio de busca.
        List<EntityMob> nearbyMobs = this.ribo.world.getEntitiesWithinAABB(
                EntityMob.class,
                this.ribo.getEntityBoundingBox().grow(FLEE_SEARCH_RADIUS)
        );

        if (nearbyMobs.isEmpty())
        {
            return false;
        }

        this.threat = nearbyMobs.get(0);
        return true;
    }

    @Override
    public boolean shouldContinueExecuting()
    {
        return !this.ribo.getNavigator().noPath();
    }

    @Override
    public void startExecuting()
    {
        // Cancela qualquer ordem de mineracao em andamento: a sobrevivencia vem primeiro.
        this.ribo.setMiningOrderActive(false);

        // Calcula um ponto de fuga na direcao oposta a ameaca.
        Vec3d fleeVec = RandomPositionGenerator.findRandomTargetBlockAwayFrom(
                this.ribo, 16, 7, new Vec3d(this.threat.posX, this.threat.posY, this.threat.posZ)
        );

        if (fleeVec != null)
        {
            this.fleeX = fleeVec.x;
            this.fleeY = fleeVec.y;
            this.fleeZ = fleeVec.z;
            this.ribo.getNavigator().tryMoveToXYZ(this.fleeX, this.fleeY, this.fleeZ, FLEE_SPEED);
        }
    }

    @Override
    public void updateTask()
    {
        // Continua de olho na ameaca enquanto corre.
        this.ribo.getLookHelper().setLookPosition(this.threat.posX, this.threat.posY, this.threat.posZ, 10.0F, this.ribo.getVerticalFaceSpeed());
    }

    @Override
    public void resetTask()
    {
        this.threat = null;
    }
}
