package com.ribomod.ribo.client.gui;

import com.ribomod.ribo.RiboMod;
import com.ribomod.ribo.inventory.ContainerRibo;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * GuiRibo
 *
 * Tela (client-side) do inventario do kit do Ribo. Desenha a textura de fundo
 * (estilo vanilla simples, gerada especificamente para este mod) e um titulo.
 * Toda a logica real de slots/itens fica no ContainerRibo (server-authoritative).
 */
@SideOnly(Side.CLIENT)
public class GuiRibo extends GuiContainer
{
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(RiboMod.MODID, "textures/gui/gui_ribo.png");

    public GuiRibo(EntityPlayer player, ContainerRibo container)
    {
        super(container);
        this.xSize = 176;
        this.ySize = 166;
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY)
    {
        this.mc.getTextureManager().bindTexture(TEXTURE);
        int x = (this.width - this.xSize) / 2;
        int y = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
    {
        // Titulo da janela. Os 2 slots do kit ja ficam visualmente destacados na textura
        // de fundo (acima do inventario do jogador), entao um unico titulo basta - texto
        // extra colado nos slots tende a colidir visualmente com a borda deles.
        this.fontRenderer.drawString("Kit do Ribo", 8, 6, 0x404040);
    }
}
