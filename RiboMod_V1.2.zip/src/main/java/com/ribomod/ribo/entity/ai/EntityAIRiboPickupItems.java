package com.ribomod.ribo.entity.ai;

import com.ribomod.ribo.entity.EntityRibo;
import com.ribomod.ribo.inventory.RiboKitInventory;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;

import java.util.List;

/**
 * EntityAIRiboPickupItems
 *
 * Faz o Ribo notar e ir buscar itens dropados no chao perto dele, mas SOMENTE
 * picareta (qualquer material) ou tochas - qualquer outro item dropado e
 * ignorado e permanece no chao.
 *
 * Fluxo:
 * 1. Procura, num raio pequeno, a EntityItem mais proxima que seja picareta ou tocha.
 * 2. Caminha até o item.
 * 3. Ao chegar perto, "pega" o item: remove a EntityItem do mundo e coloca o
 *    conteudo no slot correspondente do RiboKitInventory (picareta -> slot 0,
 *    tocha -> slot 1). Se o slot já tiver algo incompativel ou cheio, o item
 *    simplesmente nao e absorvido (fica no chao).
 *
 * Essa tarefa tem prioridade ALTA (mas abaixo da fuga), pois faz parte do fluxo
 * de "o jogador entrega o kit ao Ribo" descrito nas regras do mod.
 */
public class EntityAIRiboPickupItems extends EntityAIBase
{
    private final EntityRibo ribo;
    private EntityItem targetItem;
    private static final double SEARCH_RADIUS = 6.0D;

    public EntityAIRiboPickupItems(EntityRibo ribo)
    {
        this.ribo = ribo;
        this.setMutexBits(1);
    }

    @Override
    public boolean shouldExecute()
    {
        // Nao busca itens enquanto esta minerando ou descansando (essas tasks tomam prioridade).
        if (this.ribo.isMiningOrderActive() || this.ribo.isResting())
        {
            return false;
        }

        this.targetItem = findNearestRelevantItem();
        return this.targetItem != null;
    }

    @Override
    public boolean shouldContinueExecuting()
    {
        return this.targetItem != null
                && this.targetItem.isEntityAlive()
                && !this.ribo.isMiningOrderActive()
                && !this.ribo.isResting();
    }

    @Override
    public void resetTask()
    {
        this.targetItem = null;
        this.ribo.getNavigator().clearPath();
    }

    @Override
    public void updateTask()
    {
        if (this.targetItem == null)
        {
            return;
        }

        double distSq = this.ribo.getDistanceSq(this.targetItem);
        if (distSq > 2.5D)
        {
            this.ribo.getNavigator().tryMoveToEntityLiving(this.targetItem, 1.0D);
            return;
        }

        // Perto o suficiente: "pega" o item do chao.
        pickUpItem(this.targetItem);
        this.targetItem = null;
        this.ribo.getNavigator().clearPath();
    }

    /**
     * Move o conteudo da EntityItem dropada para o slot correto do kit do Ribo
     * (picareta ou tocha), e remove a entidade do mundo. Itens que nao cabem
     * (slot ja ocupado por algo incompativel, ou kit ja completo) permanecem
     * intocados no chao.
     */
    private void pickUpItem(EntityItem entityItem)
    {
        ItemStack stack = entityItem.getItem();
        RiboKitInventory kit = this.ribo.getKitInventory();

        if (RiboKitInventory.isPickaxe(stack))
        {
            if (kit.getStackInSlot(RiboKitInventory.SLOT_PICKAXE).isEmpty())
            {
                kit.setInventorySlotContents(RiboKitInventory.SLOT_PICKAXE, stack.copy());
                entityItem.setDead(); // remove o item do mundo, ja foi absorvido
            }
        }
        else if (RiboKitInventory.isTorch(stack))
        {
            ItemStack existing = kit.getStackInSlot(RiboKitInventory.SLOT_TORCHES);
            if (existing.isEmpty())
            {
                kit.setInventorySlotContents(RiboKitInventory.SLOT_TORCHES, stack.copy());
                entityItem.setDead();
            }
            else if (RiboKitInventory.isTorch(existing) && existing.getCount() < kit.getInventoryStackLimit())
            {
                int spaceLeft = kit.getInventoryStackLimit() - existing.getCount();
                int toAdd = Math.min(spaceLeft, stack.getCount());
                existing.grow(toAdd);
                stack.shrink(toAdd);
                kit.notifyKitChanged(); // forca a checagem de kit completo apos acumular tochas no slot existente
                if (stack.isEmpty())
                {
                    entityItem.setDead();
                }
            }
        }
        // Qualquer outro tipo de item: nao faz nada, permanece no chao (ja filtrado em findNearestRelevantItem).
    }

    /** Procura, num raio pequeno, a EntityItem mais proxima que seja picareta ou tocha. */
    private EntityItem findNearestRelevantItem()
    {
        List<EntityItem> nearbyItems = this.ribo.world.getEntitiesWithinAABB(
                EntityItem.class,
                this.ribo.getEntityBoundingBox().grow(SEARCH_RADIUS)
        );

        EntityItem closest = null;
        double closestDistSq = Double.MAX_VALUE;

        for (EntityItem entityItem : nearbyItems)
        {
            if (!entityItem.isEntityAlive())
            {
                continue;
            }
            ItemStack stack = entityItem.getItem();
            if (!RiboKitInventory.isPickaxe(stack) && !RiboKitInventory.isTorch(stack))
            {
                continue; // ignora qualquer item que nao seja picareta ou tocha
            }

            double distSq = this.ribo.getDistanceSq(entityItem);
            if (distSq < closestDistSq)
            {
                closestDistSq = distSq;
                closest = entityItem;
            }
        }

        return closest;
    }
}
