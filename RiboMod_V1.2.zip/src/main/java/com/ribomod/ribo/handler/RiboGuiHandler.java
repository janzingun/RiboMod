package com.ribomod.ribo.handler;

import com.ribomod.ribo.client.gui.GuiRibo;
import com.ribomod.ribo.entity.EntityRibo;
import com.ribomod.ribo.inventory.ContainerRibo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

/**
 * RiboGuiHandler
 *
 * Handler padrao do Forge que liga um ID de GUI a um Container (servidor) e uma
 * Gui (cliente). O "ID da entidade" (x, y, z aqui sao reaproveitados como o ID
 * da entidade do Ribo, ver RiboEventHandler) e usado para localizar de volta
 * qual EntityRibo deve ser aberto.
 */
public class RiboGuiHandler implements IGuiHandler
{
    public static final int GUI_ID_RIBO_KIT = 0;

    @Override
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
    {
        if (id == GUI_ID_RIBO_KIT)
        {
            EntityRibo ribo = findRiboById(world, x);
            if (ribo != null)
            {
                return new ContainerRibo(player, ribo);
            }
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z)
    {
        if (id == GUI_ID_RIBO_KIT)
        {
            EntityRibo ribo = findRiboById(world, x);
            if (ribo != null)
            {
                return new GuiRibo(player, new ContainerRibo(player, ribo));
            }
        }
        return null;
    }

    /** Reaproveita o parametro "x" como o ID da entidade do Ribo, ja que IGuiHandler so aceita 3 ints. */
    private EntityRibo findRiboById(World world, int entityId)
    {
        Entity entity = world.getEntityByID(entityId);
        if (entity instanceof EntityRibo)
        {
            return (EntityRibo) entity;
        }
        return null;
    }
}
