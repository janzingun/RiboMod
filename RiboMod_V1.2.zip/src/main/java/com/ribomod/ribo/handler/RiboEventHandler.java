package com.ribomod.ribo.handler;

import com.ribomod.ribo.RiboMod;
import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * RiboEventHandler
 *
 * Responsavel por:
 * 1. Spawnar o Ribo automaticamente ao lado do jogador na primeira vez que ele
 *    entra no mundo (login), usando uma flag salva no NBT do jogador para garantir
 *    que isso so aconteca uma unica vez por jogador.
 * 2. Detectar a morte do Ribo e agendar o nascimento de um novo Ribo (substituto)
 *    no mesmo local, pertencente ao mesmo dono, apos um pequeno atraso.
 * 3. Permitir conversa LIVRE com o Ribo pelo chat do jogo: qualquer mensagem do
 *    dono enquanto o Ribo esta por perto recebe uma resposta contextual.
 * 4. Processar a interacao do jogador com o Ribo:
 *    - clique direito normal -> dialogo de status + entrega automatica dos
 *      minerios coletados para o inventario do jogador;
 *    - SHIFT + clique direito -> abre a GUI do kit do Ribo (2 slots: picareta
 *      e tochas), onde o jogador pode colocar os itens manualmente.
 *    (A outra forma de entregar o kit - largar os itens no chao perto do Ribo -
 *    e tratada pela EntityAIRiboPickupItems, nao por este handler.)
 */
public class RiboEventHandler
{
    // Controle simples em memoria para nao tentar spawnar de novo no mesmo login.
    private final Set<UUID> alreadySpawnedThisSession = new HashSet<>();

    /** Atraso (em ticks) antes do Ribo substituto nascer apos a morte do anterior. */
    private static final int RESPAWN_DELAY_TICKS = 20 * 5; // 5 segundos

    /** Fila de respawns agendados: cada entrada vira um novo Ribo quando seu cooldown chega a 0. */
    private final List<PendingRespawn> pendingRespawns = new ArrayList<>();

    /** Estrutura simples guardando onde e para quem o proximo Ribo deve nascer. */
    private static class PendingRespawn
    {
        final World world;
        final double x, y, z;
        final UUID ownerUUID;
        int ticksRemaining;

        PendingRespawn(World world, double x, double y, double z, UUID ownerUUID, int ticksRemaining)
        {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.ownerUUID = ownerUUID;
            this.ticksRemaining = ticksRemaining;
        }
    }

    /**
     * Dispara quando o jogador entra no mundo (login ou respawn no overworld pela primeira vez).
     * Usamos uma tag persistente no NBT do jogador ("RiboHasSpawned") para garantir que o
     * Ribo apareca apenas UMA vez na vida daquele jogador, mesmo que ele relogue depois.
     */
    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event)
    {
        EntityPlayer player = event.player;
        if (!(player instanceof EntityPlayerMP))
        {
            return;
        }

        if (this.alreadySpawnedThisSession.contains(player.getUniqueID()))
        {
            return;
        }

        boolean hasSpawnedBefore = player.getEntityData().getBoolean("RiboHasSpawned");
        if (hasSpawnedBefore)
        {
            return;
        }

        spawnRiboNextToPlayer(player);
        player.getEntityData().setBoolean("RiboHasSpawned", true);
        this.alreadySpawnedThisSession.add(player.getUniqueID());
    }

    private void spawnRiboNextToPlayer(EntityPlayer player)
    {
        // Posiciona o Ribo a 2 blocos de distancia do jogador, na mesma altura.
        double spawnX = player.posX + 2.0;
        double spawnY = player.posY;
        double spawnZ = player.posZ;

        spawnRiboAt(player.world, spawnX, spawnY, spawnZ, player.rotationYaw, player.getUniqueID());

        player.sendMessage(new TextComponentString(
                TextFormatting.GREEN + "Ribo" + TextFormatting.WHITE + " apareceu para te acompanhar na sua jornada!"
        ));
    }

    /**
     * Cria e spawna uma instancia de EntityRibo em uma posicao especifica, pertencente
     * ao dono informado. Usado tanto para o spawn inicial (login) quanto para o
     * RESPAWN apos a morte do Ribo anterior.
     */
    private void spawnRiboAt(World world, double x, double y, double z, float yaw, UUID ownerUUID)
    {
        EntityRibo ribo = new EntityRibo(world);
        ribo.setLocationAndAngles(x, y, z, yaw, 0.0F);
        ribo.setOwnerUUID(ownerUUID);
        ribo.setHomeAnchor(ribo.getPosition());
        ribo.enablePersistence(); // garante que o Ribo nao seja removido por despawn natural

        world.spawnEntity(ribo);
    }

    /**
     * Detecta a morte do Ribo (seja por monstro, queda, lava etc.) e agenda o
     * nascimento de um Ribo SUBSTITUTO no mesmo local, para o mesmo dono, apos
     * RESPAWN_DELAY_TICKS. O Ribo novo nasce com energia e inventario zerados
     * (e um "novo" companheiro, nao uma ressurreicao com o inventario antigo).
     */
    @SubscribeEvent
    public void onRiboDeath(LivingDeathEvent event)
    {
        if (!(event.getEntity() instanceof EntityRibo))
        {
            return;
        }

        EntityRibo ribo = (EntityRibo) event.getEntity();
        UUID ownerUUID = ribo.getOwnerUUID();
        if (ownerUUID == null)
        {
            return; // Ribo sem dono (nao deveria acontecer), nao agenda substituto
        }

        // Avisa o dono, se ele estiver online, antes do Ribo desaparecer.
        EntityPlayer owner = ribo.getOwner();
        if (owner != null)
        {
            owner.sendMessage(new TextComponentString(
                    TextFormatting.RED + "Ribo caiu em combate..." + TextFormatting.WHITE +
                            " Um novo companheiro deve chegar em breve."
            ));
        }

        this.pendingRespawns.add(new PendingRespawn(
                ribo.world, ribo.posX, ribo.posY, ribo.posZ, ownerUUID, RESPAWN_DELAY_TICKS
        ));
    }

    /**
     * A cada tick do servidor, decrementa o cooldown de cada respawn pendente e
     * spawna o Ribo substituto quando o tempo se esgota.
     */
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event)
    {
        if (event.phase != TickEvent.Phase.END || this.pendingRespawns.isEmpty())
        {
            return;
        }

        for (int i = this.pendingRespawns.size() - 1; i >= 0; i--)
        {
            PendingRespawn pending = this.pendingRespawns.get(i);
            pending.ticksRemaining--;

            if (pending.ticksRemaining <= 0)
            {
                spawnRiboAt(pending.world, pending.x, pending.y, pending.z, 0.0F, pending.ownerUUID);

                EntityPlayer owner = pending.world.getPlayerEntityByUUID(pending.ownerUUID);
                if (owner != null)
                {
                    owner.sendMessage(new TextComponentString(
                            TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                                    "Ola de novo! Sou um novo Ribo, pronto para te ajudar."
                    ));
                }

                this.pendingRespawns.remove(i);
            }
        }
    }

    /**
     * Intercepta o chat do jogador para permitir CONVERSA LIVRE com o Ribo.
     * Em vez de exigir comandos exatos com prefixo "ribo", qualquer mensagem do
     * dono e analisada por palavras-chave e recebe uma resposta contextual:
     *   - mencoes a "minerar"/"cavar"/"trabalhar" -> NAO inicia a mineracao direto;
     *     apenas explica que o jogador precisa largar 1 picareta + 32 tochas perto
     *     do Ribo (ou colocar na GUI dele via shift + clique). A mineracao comeca
     *     automaticamente quando esse kit fica completo (EntityRibo.onKitDelivered).
     *   - mencoes a "parar"/"pare"/"descansar" -> cancela a ordem de mineracao
     *   - saudacoes ("oi", "ola", "bom dia"...) -> resposta de saudacao
     *   - perguntas sobre estado ("como voce esta", "tudo bem"...) -> status atual
     *   - agradecimentos ("obrigado", "valeu"...) -> resposta simpatica
     *   - qualquer outra coisa -> resposta generica, mantendo a conversa "viva"
     *
     * A mensagem original do jogador NUNCA e cancelada (event.setCanceled nao e mais
     * chamado aqui), entao a conversa flui livremente no chat publico do servidor:
     * outros jogadores continuam vendo o que foi digitado, e o Ribo apenas
     * "participa" da conversa com sua propria mensagem em seguida.
     */
    @SubscribeEvent
    public void onPlayerChat(ServerChatEvent event)
    {
        String msg = event.getMessage().trim().toLowerCase();
        EntityPlayer player = event.getPlayer();

        EntityRibo ribo = findRiboOwnedBy(player);
        if (ribo == null)
        {
            return; // jogador nao possui um Ribo proximo, nao intervem no chat
        }

        String reply = buildRiboReply(ribo, player, msg);
        if (reply != null)
        {
            // Pequeno atraso natural seria ideal, mas em chat simples respondemos direto.
            player.sendMessage(new TextComponentString(TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE + reply));
        }
    }

    /**
     * Interpreta a mensagem do jogador por palavras-chave e decide a resposta/acao do Ribo.
     * Retorna o texto de resposta, ou null se por algum motivo nao houver nada a dizer
     * (nao deveria acontecer, sempre ha um fallback generico).
     */
    private String buildRiboReply(EntityRibo ribo, EntityPlayer player, String msg)
    {
        // ===================== ORDEM DE MINERAR (via chat) =====================
        // O chat NAO entrega mais o kit automaticamente: agora o jogador precisa
        // largar a picareta + 32 tochas no chao perto do Ribo, OU abrir a GUI dele
        // (SHIFT + clique direito) e colocar os itens manualmente. Assim que o kit
        // fica completo, EntityRibo.onKitDelivered() inicia a mineracao sozinho.
        // Aqui so respondemos explicando isso, ou avisando o status atual.
        if (containsAny(msg, "minerar", "minera", "cavar", "cava", "trabalhar", "trabalha"))
        {
            if (ribo.isResting())
            {
                return "Estou descansando, preciso recuperar energia antes de continuar...";
            }
            if (ribo.isMiningOrderActive())
            {
                return "Ja estou trabalhando nisso! Energia: " + ribo.getEnergy() + "/" + EntityRibo.MAX_ENERGY + ".";
            }
            return "Para eu minerar, preciso de uma picareta e 32 tochas. Pode largar no chao perto de mim, "
                    + "ou abrir meu inventario (shift + clique em mim) e colocar ai!";
        }

        // ===================== ORDEM DE PARAR =====================
        // Usa containsWord (palavra inteira) em vez de containsAny para evitar falso positivo
        // com a preposicao comum "para" (ex: "isso e para voce" nao deve cancelar a mineracao).
        if (containsWord(msg, "parar", "pare", "descansar", "descanse", "chega", "pausa"))
        {
            ribo.setMiningOrderActive(false);
            return "Ok, parei o que estava fazendo.";
        }

        // ===================== SAUDACOES =====================
        if (containsAny(msg, "oi", "ola", "ei ribo", "bom dia", "boa tarde", "boa noite", "salve"))
        {
            return "Ola! Que bom te ver. Precisa de alguma coisa?";
        }

        // ===================== PERGUNTAS DE STATUS =====================
        if (containsAny(msg, "como voce esta", "como vc esta", "tudo bem", "tudo bom", "status", "energia"))
        {
            if (ribo.isResting())
            {
                int secondsLeft = ribo.getRestTicksRemaining() / 20;
                return "Estou bem cansado, descansando ainda por " + secondsLeft + "s.";
            }
            if (ribo.isMiningOrderActive())
            {
                return "Estou trabalhando! Energia: " + ribo.getEnergy() + "/" + EntityRibo.MAX_ENERGY + ".";
            }
            return "Estou bem, energia em " + ribo.getEnergy() + "/" + EntityRibo.MAX_ENERGY + ". Pronto para ajudar!";
        }

        // ===================== AGRADECIMENTOS =====================
        if (containsAny(msg, "obrigado", "obrigada", "valeu", "gracas", "thanks"))
        {
            return "De nada! Estou aqui para isso.";
        }

        // ===================== DESPEDIDAS =====================
        if (containsAny(msg, "tchau", "ate logo", "ate mais", "adeus"))
        {
            return "Ate logo! Vou continuar por aqui te esperando.";
        }

        // ===================== FALLBACK GENERICO =====================
        // Mantem a conversa "viva" mesmo quando o Ribo nao reconhece nenhuma palavra-chave.
        return "Hmm, nao tenho certeza do que voce quer dizer, mas estou aqui se precisar de mim!";
    }

    /** Util simples para checar se a mensagem contem qualquer uma das palavras/expressoes informadas. */
    private boolean containsAny(String msg, String... keywords)
    {
        for (String keyword : keywords)
        {
            if (msg.contains(keyword))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Como containsAny, mas exige que a palavra apareca isolada (delimitada por espacos
     * ou bordas da string), evitando falsos positivos como "para" dentro de "para voce".
     */
    private boolean containsWord(String msg, String... words)
    {
        for (String word : words)
        {
            if (msg.matches(".*\\b" + word + "\\b.*"))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Clique direito no Ribo: saudacao + informe de status + entrega automatica
     * dos minerios coletados para o inventario do jogador.
     */
    @SubscribeEvent
    public void onPlayerInteractWithRibo(PlayerInteractEvent.EntityInteract event)
    {
        if (!(event.getTarget() instanceof EntityRibo))
        {
            return;
        }

        EntityRibo ribo = (EntityRibo) event.getTarget();
        EntityPlayer player = event.getEntityPlayer();

        // So responde/entrega itens para o proprio dono.
        if (ribo.getOwnerUUID() == null || !ribo.getOwnerUUID().equals(player.getUniqueID()))
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GRAY + "Ribo olha para voce, mas parece nao te reconhecer."
            ));
            return;
        }

        event.setCanceled(true); // evita qualquer outra interacao padrao (ex: GUI de aldeao)

        // ===================== SHIFT + CLIQUE DIREITO: ABRE A GUI DO KIT =====================
        // Em vez do dialogo normal, abre o inventario do Ribo (2 slots: picareta + tochas),
        // onde o jogador pode colocar os itens manualmente para liberar a mineracao.
        if (player.isSneaking())
        {
            if (!(player instanceof EntityPlayerMP))
            {
                return; // GUI so e aberta a partir do lado do servidor
            }
            ((EntityPlayerMP) player).openGui(
                    RiboMod.instance,
                    RiboGuiHandler.GUI_ID_RIBO_KIT,
                    ribo.world,
                    ribo.getEntityId(), 0, 0
            );
            return;
        }

        // ===================== CLIQUE NORMAL: DIALOGO DE STATUS =====================
        if (ribo.isResting())
        {
            int secondsLeft = ribo.getRestTicksRemaining() / 20;
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Estou cansado e preciso descansar. Faltam aproximadamente " + secondsLeft + "s."
            ));
        }
        else if (ribo.isMiningOrderActive())
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Estou minerando por aqui! Energia atual: " + ribo.getEnergy() + "/" + EntityRibo.MAX_ENERGY + "."
            ));
        }
        else
        {
            player.sendMessage(new TextComponentString(
                    TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                            "Ola! Pode falar comigo pelo chat. Para eu minerar, largue uma picareta e 32 tochas "
                                    + "perto de mim, ou abra meu inventario com shift + clique e coloque ai!"
            ));
        }

        // ===================== ENTREGA DOS MINERIOS COLETADOS =====================
        if (ribo.hasOresToDeliver())
        {
            int itemsDelivered = deliverOresToPlayer(ribo, player);
            if (itemsDelivered > 0)
            {
                player.sendMessage(new TextComponentString(
                        TextFormatting.GOLD + "Ribo: " + TextFormatting.WHITE +
                                "Aqui estao os minerios que coletei para voce!"
                ));
            }
        }
    }

    /**
     * Transfere todo o conteudo do inventario interno do Ribo para o inventario do jogador.
     * Caso o inventario do jogador esteja cheio, o item que nao couber e dropado no chao
     * proximo ao jogador (nunca e perdido).
     */
    private int deliverOresToPlayer(EntityRibo ribo, EntityPlayer player)
    {
        int count = 0;
        for (int i = 0; i < ribo.getOreInventory().size(); i++)
        {
            ItemStack stack = ribo.getOreInventory().get(i);
            if (!stack.isEmpty())
            {
                boolean added = player.inventory.addItemStackToInventory(stack);
                if (!added || !stack.isEmpty())
                {
                    // Inventario do jogador cheio: dropa o restante no chao ao lado dele.
                    player.dropItem(stack, false);
                }
                count++;
            }
        }
        ribo.clearOreInventory();
        return count;
    }

    /** Procura, entre as entidades carregadas no mundo do jogador, o Ribo cujo dono e este jogador. */
    private EntityRibo findRiboOwnedBy(EntityPlayer player)
    {
        for (Entity entity : player.world.loadedEntityList)
        {
            if (entity instanceof EntityRibo)
            {
                EntityRibo ribo = (EntityRibo) entity;
                if (player.getUniqueID().equals(ribo.getOwnerUUID()))
                {
                    return ribo;
                }
            }
        }
        return null;
    }
}
