package com.ribomod.ribo.inventory;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

/**
 * ContainerRibo
 *
 * Container (logica server-authoritative de GUI) para o inventario do kit do Ribo.
 * Mostra apenas os 2 slots do kit (picareta + tochas) e, abaixo, o inventario
 * principal + hotbar do jogador, igual a qualquer GUI de bau simples.
 *
 * Os slots do kit usam Slot customizados que rejeitam itens incompativeis
 * (isItemValid delega para RiboKitInventory.isItemValidForSlot), entao o jogador
 * so consegue colocar picareta no slot de picareta e tocha no slot de tocha.
 */
public class ContainerRibo extends Container
{
    private final RiboKitInventory kitInventory;
    private static final int KIT_SLOTS = 2;

    public ContainerRibo(EntityPlayer player, EntityRibo ribo)
    {
        this.kitInventory = ribo.getKitInventory();

        // ===================== SLOTS DO KIT (picareta + tocha) =====================
        // Posicionados lado a lado, perto do topo da GUI.
        this.addSlotToContainer(new Slot(this.kitInventory, RiboKitInventory.SLOT_PICKAXE, 62, 20)
        {
            @Override
            public boolean isItemValid(ItemStack stack)
            {
                return RiboKitInventory.isPickaxe(stack);
            }
        });
        this.addSlotToContainer(new Slot(this.kitInventory, RiboKitInventory.SLOT_TORCHES, 98, 20)
        {
            @Override
            public boolean isItemValid(ItemStack stack)
            {
                return RiboKitInventory.isTorch(stack);
            }
        });

        // ===================== INVENTARIO DO JOGADOR =====================
        // Inventario principal (3 linhas de 9).
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 9; col++)
            {
                int index = col + row * 9 + 9; // pula a hotbar (slots 0-8), comeca no inventario principal
                this.addSlotToContainer(new Slot(player.inventory, index, 8 + col * 18, 51 + row * 18));
            }
        }
        // Hotbar (1 linha de 9).
        for (int col = 0; col < 9; col++)
        {
            this.addSlotToContainer(new Slot(player.inventory, col, 8 + col * 18, 109));
        }
    }

    @Override
    public boolean canInteractWith(EntityPlayer player)
    {
        return this.kitInventory.isUsableByPlayer(player);
    }

    /**
     * Implementa o shift-clique (transferStackInSlot) para mover itens rapidamente
     * entre o inventario do jogador e os slots do kit, respeitando o filtro de
     * cada slot (picareta so vai pro slot 0, tocha so vai pro slot 1).
     */
    @Override
    public ItemStack transferStackInSlot(EntityPlayer player, int index)
    {
        Slot sourceSlot = this.inventorySlots.get(index);
        if (sourceSlot == null || !sourceSlot.getHasStack())
        {
            return ItemStack.EMPTY;
        }

        ItemStack sourceStack = sourceSlot.getStack();
        ItemStack originalStack = sourceStack.copy();

        if (index < KIT_SLOTS)
        {
            // Clicou em um slot do kit: manda para o inventario do jogador.
            if (!this.mergeItemStack(sourceStack, KIT_SLOTS, this.inventorySlots.size(), true))
            {
                return ItemStack.EMPTY;
            }
        }
        else
        {
            // Clicou no inventario do jogador: tenta mandar para o slot correto do kit.
            if (RiboKitInventory.isPickaxe(sourceStack))
            {
                if (!this.mergeItemStack(sourceStack, RiboKitInventory.SLOT_PICKAXE, RiboKitInventory.SLOT_PICKAXE + 1, false))
                {
                    return ItemStack.EMPTY;
                }
            }
            else if (RiboKitInventory.isTorch(sourceStack))
            {
                if (!this.mergeItemStack(sourceStack, RiboKitInventory.SLOT_TORCHES, RiboKitInventory.SLOT_TORCHES + 1, false))
                {
                    return ItemStack.EMPTY;
                }
            }
            else
            {
                return ItemStack.EMPTY; // item nao pertence ao kit, shift-clique nao faz nada
            }
        }

        if (sourceStack.isEmpty())
        {
            sourceSlot.putStack(ItemStack.EMPTY);
        }
        else
        {
            sourceSlot.onSlotChanged();
        }

        if (sourceStack.getCount() == originalStack.getCount())
        {
            return ItemStack.EMPTY;
        }

        sourceSlot.onTake(player, sourceStack);
        return originalStack;
    }
}
