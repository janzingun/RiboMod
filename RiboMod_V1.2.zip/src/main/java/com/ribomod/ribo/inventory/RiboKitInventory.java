package com.ribomod.ribo.inventory;

import com.ribomod.ribo.entity.EntityRibo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

/**
 * RiboKitInventory
 *
 * Inventario simples de 2 slots que representa o "kit de mineracao" que o jogador
 * precisa entregar ao Ribo antes dele aceitar trabalhar:
 *   - Slot 0: uma picareta (qualquer material)
 *   - Slot 1: tochas (precisa ter pelo menos TORCHES_REQUIRED unidades)
 *
 * O jogador pode preencher esses slots de duas formas:
 *   1. Largando os itens no chao perto do Ribo (EntityAIRiboPickupItems detecta e
 *      coloca aqui automaticamente);
 *   2. Abrindo a GUI do Ribo com SHIFT + clique direito e arrastando os itens
 *      manualmente para os slots (ContainerRibo/GuiRibo).
 *
 * Implementa IInventory para poder ser usado dentro de um Container padrao do Forge.
 */
public class RiboKitInventory implements IInventory
{
    /** Quantidade minima de tochas necessaria para liberar a mineracao. */
    public static final int TORCHES_REQUIRED = 32;

    public static final int SLOT_PICKAXE = 0;
    public static final int SLOT_TORCHES = 1;
    private static final int SIZE = 2;

    private final EntityRibo ribo;
    private final NonNullList<ItemStack> slots = NonNullList.withSize(SIZE, ItemStack.EMPTY);

    public RiboKitInventory(EntityRibo ribo)
    {
        this.ribo = ribo;
    }

    /** Considera valido qualquer picareta vanilla (madeira, pedra, ferro, ouro ou diamante). */
    public static boolean isPickaxe(ItemStack stack)
    {
        if (stack.isEmpty())
        {
            return false;
        }
        Item item = stack.getItem();
        return item == Items.WOODEN_PICKAXE || item == Items.STONE_PICKAXE
                || item == Items.IRON_PICKAXE || item == Items.GOLDEN_PICKAXE
                || item == Items.DIAMOND_PICKAXE;
    }

    public static boolean isTorch(ItemStack stack)
    }
    return !stack.isEmpty() && stack.getItem() == Item.getItemFromBlock(Blocks.TORCH);
    }

    /** Verdadeiro quando o kit esta completo: 1 picareta + tochas suficientes. */
    public boolean isKitComplete()
    {
        ItemStack pickaxe = this.slots.get(SLOT_PICKAXE);
        ItemStack torches = this.slots.get(SLOT_TORCHES);
        return isPickaxe(pickaxe) && isTorch(torches) && torches.getCount() >= TORCHES_REQUIRED;
    }

    /** Consome o kit (esvazia os 2 slots). Chamado quando a mineracao e iniciada. */
    public void consumeKit()
    {
        this.slots.set(SLOT_PICKAXE, ItemStack.EMPTY);
        this.slots.set(SLOT_TORCHES, ItemStack.EMPTY);
    }

    // ===================== IMPLEMENTACAO DE IInventory =====================

    @Override
    public int getSizeInventory()
    {
        return SIZE;
    }

    @Override
    public boolean isEmpty()
    {
        for (ItemStack stack : this.slots)
        {
            if (!stack.isEmpty())
            {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getStackInSlot(int index)
    {
        return this.slots.get(index);
    }

    @Override
    public ItemStack decrStackSize(int index, int count)
    {
        ItemStack stack = this.slots.get(index);
        if (stack.isEmpty())
        {
            return ItemStack.EMPTY;
        }
        ItemStack result = stack.splitStack(Math.min(count, stack.getCount()));
        if (stack.isEmpty())
        {
            this.slots.set(index, ItemStack.EMPTY);
        }
        this.markDirtyAndCheckKit();
        return result;
    }

    @Override
    public ItemStack removeStackFromSlot(int index)
    {
        ItemStack stack = this.slots.get(index);
        this.slots.set(index, ItemStack.EMPTY);
        this.markDirtyAndCheckKit();
        return stack;
    }

    @Override
    public void setInventorySlotContents(int index, ItemStack stack)
    {
        // Filtro por slot: slot 0 so aceita picareta, slot 1 so aceita tocha.
        // Itens incompativeis simplesmente nao sao aceitos (o Container/GUI deve
        // respeitar isso via isItemValidForSlot, isso aqui e uma segunda barreira).
        if (index == SLOT_PICKAXE && !stack.isEmpty() && !isPickaxe(stack))
        {
            return;
        }
        if (index == SLOT_TORCHES && !stack.isEmpty() && !isTorch(stack))
        {
            return;
        }

        this.slots.set(index, stack);
        if (stack.getCount() > this.getInventoryStackLimit())
        {
            stack.setCount(this.getInventoryStackLimit());
        }
        this.markDirtyAndCheckKit();
    }

    @Override
    public int getInventoryStackLimit()
    {
        return 64;
    }

    @Override
    public void markDirty()
    {
        // Sem efeito extra aqui; markDirtyAndCheckKit cobre a logica real.
    }

    /** Centraliza o "markDirty" real: sempre que o conteudo muda, verifica se o kit ficou completo. */
    private void markDirtyAndCheckKit()
    {
        if (this.isKitComplete())
        {
            this.ribo.onKitDelivered();
        }
    }

    /**
     * Versao publica de markDirtyAndCheckKit, para ser chamada por codigo externo
     * (como EntityAIRiboPickupItems) apos modificar um ItemStack diretamente via
     * ItemStack.grow()/shrink() sem passar por setInventorySlotContents.
     */
    public void notifyKitChanged()
    {
        this.markDirtyAndCheckKit();
    }

    @Override
    public boolean isUsableByPlayer(EntityPlayer player)
    {
        // So o dono pode abrir o inventario do Ribo.
        return this.ribo.getOwnerUUID() != null && this.ribo.getOwnerUUID().equals(player.getUniqueID())
                && this.ribo.isEntityAlive();
    }

    @Override
    public void openInventory(EntityPlayer player)
    {
        // Sem efeito especial ao abrir.
    }

    @Override
    public void closeInventory(EntityPlayer player)
    {
        // Ao fechar a GUI, verifica novamente se o kit ficou completo (seguranca extra).
        this.markDirtyAndCheckKit();
    }

    @Override
    public boolean isItemValidForSlot(int index, ItemStack stack)
    {
        if (index == SLOT_PICKAXE)
        {
            return isPickaxe(stack);
        }
        if (index == SLOT_TORCHES)
        {
            return isTorch(stack);
        }
        return false;
    }

    // ===================== METODOS DE IInventory SEM USO REAL AQUI =====================

    @Override
    public int getField(int id) { return 0; }

    @Override
    public void setField(int id, int value) { }

    @Override
    public int getFieldCount() { return 0; }

    @Override
    public void clear()
    {
        this.consumeKit();
    }

    @Override
    public String getName()
    {
        return "container.ribo_kit";
    }

    @Override
    public boolean hasCustomName()
    {
        return false;
    }

    @Override
    public ITextComponent getDisplayName()
    {
        return new TextComponentString("Kit do Ribo");
    }

    // ===================== PERSISTENCIA (NBT) =====================

    public void writeToNBT(NBTTagCompound compound)
    {
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < this.slots.size(); i++)
        {
            ItemStack stack = this.slots.get(i);
            if (!stack.isEmpty())
            {
                NBTTagCompound itemTag = new NBTTagCompound();
                itemTag.setInteger("Slot", i);
                stack.writeToNBT(itemTag);
                list.appendTag(itemTag);
            }
        }
        compound.setTag("RiboKitInventory", list);
    }

    public void readFromNBT(NBTTagCompound compound)
    {
        NBTTagList list = compound.getTagList("RiboKitInventory", 10); // 10 = NBTTagCompound
        for (int i = 0; i < list.tagCount(); i++)
        {
            NBTTagCompound itemTag = list.getCompoundTagAt(i);
            int slot = itemTag.getInteger("Slot");
            if (slot >= 0 && slot < this.slots.size())
            {
                this.slots.set(slot, new ItemStack(itemTag));
            }
        }
    }
}
