package com.ribomod.ribo;

import com.ribomod.ribo.handler.RiboEventHandler;
import com.ribomod.ribo.handler.RiboGuiHandler;
import com.ribomod.ribo.init.ModEntities;
import com.ribomod.ribo.proxy.CommonProxy;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;

/**
 * Classe principal do mod Ribo.
 *
 * O Ribo e um companheiro (NPC) que:
 * - Usa a skin classica do Steve;
 * - Spawna automaticamente perto do jogador (e nasce de novo, em outro corpo, se morrer);
 * - Segue o jogador (estilo lobo domesticado);
 * - Minera minerios proximos quando ordenado;
 * - So aceita minerar depois que o JOGADOR entrega 1 picareta + 32 tochas a ele,
 *   seja largando os itens no chao perto dele, seja pela GUI (shift + clique direito);
 * - Filtra apenas minerios validos (descarta pedra/terra/cascalho);
 * - Entrega os minerios coletados ao jogador via clique direito normal;
 * - Conversa livremente pelo chat do jogo;
 * - Possui sistema de energia/cansaco e foge quando a vida esta baixa.
 */
@Mod(modid = RiboMod.MODID, name = RiboMod.NAME, version = RiboMod.VERSION)
public class RiboMod
{
    public static final String MODID = "ribomod";
    public static final String NAME = "Ribo Companion Mod";
    public static final String VERSION = "1.0.0";

    // Instancia unica do mod, necessaria para EntityRegistry.registerModEntity (API antiga do Forge 1.12.2)
    @Mod.Instance(MODID)
    public static RiboMod instance;

    // Proxy: aponta para ClientProxy no client e CommonProxy no dedicated server.
    @SidedProxy(clientSide = "com.ribomod.ribo.proxy.ClientProxy", serverSide = "com.ribomod.ribo.proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
        // Registra a entidade Ribo no registro do Forge.
        ModEntities.registerEntities();
    }

    @EventHandler
    public void init(FMLInitializationEvent event)
    {
        // Registra o handler responsavel por spawnar o Ribo quando o jogador entra no mundo.
        MinecraftForge.EVENT_BUS.register(new RiboEventHandler());

        // Registra o GuiHandler (abre a GUI do kit do Ribo com shift + clique direito).
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new RiboGuiHandler());

        // Registra o renderer (skin do Steve) apenas no lado do cliente.
        proxy.registerRenderers();
    }
}
